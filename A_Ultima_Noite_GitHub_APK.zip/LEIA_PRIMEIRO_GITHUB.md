# A Última Noite — compilação online

Este pacote contém o projeto Android anexado e uma configuração do GitHub Actions.
Não contém um APK compilado. A compilação e a verificação lint serão feitas no GitHub.

## Pelo navegador do celular
1. Entre em https://github.com e crie um repositório.
2. Para usar as máquinas padrão gratuitas em repositórios públicos, selecione Public.
   O código enviado ficará visível publicamente. Repositórios privados têm franquias.
3. Extraia este ZIP e envie seu CONTEÚDO à raiz do repositório, preservando as pastas.
   Não envie apenas o ZIP: o workflow precisa estar em .github/workflows/gerar-apk.yml.
4. Caso o gerenciador de arquivos não mostre .github, habilite arquivos ocultos.
   Se necessário, use Add file > Create new file no GitHub e crie o caminho acima,
   copiando para ele o conteúdo do arquivo YAML incluído.
5. Abra Actions > Gerar APK Android > Run workflow. Um envio a main/master também inicia.
6. Depois de concluir com sucesso, abra a execução e baixe A_Ultima_Noite_APK em Artifacts.
7. Extraia o download e instale A_Ultima_Noite.apk no Android 8.0 ou superior.
   Se solicitado, permita instalar arquivos desta fonte nas configurações do aparelho.
8. Os downloads expiram após um dia. Execute novamente se precisar de outra cópia.

## O que será gerado
APK de depuração assinado automaticamente, para teste e instalação pessoal.
Não é uma versão de publicação na Play Store. A chave de teste pode mudar entre
execuções; se aparecer conflito de assinatura, desinstale a demo anterior antes
(reinstalar pode apagar dados locais).

## Conteúdo do jogo
Protótipo 2D offline com movimentação, casas e portas. Não inclui 3D realista,
login Google, multiplayer nem combate. O código do jogo foi preservado.
Não houve compilação ou teste em aparelho neste ambiente.

## Configuração
Java 17, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, SDK Android 35.
O workflow instala Gradle diretamente; não depende do wrapper incompleto no ZIP original.
A compilação gera APK e executa lint. Erros precisam ser resolvidos antes de entregar o APK.

Documentação: https://docs.github.com/en/actions/concepts/billing-and-usage
