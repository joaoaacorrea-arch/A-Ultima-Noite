# Esconde-Esconde — A Última Noite | Android Studio

## O que este ZIP realmente entrega
Um **protótipo Android nativo, offline, 2D estilizado**, com:
- Seleção de Bia ou João, papel de assassino/sobrevivente e 3/5/7 minutos;
- Mapa de floresta com oito casas e portas que abrem/fecham;
- Joystick de toque e alternância de escala de câmera (visão aproximada/ampla);
- Escolha de arma no papel de assassino;
- Cronômetro e vitória do sobrevivente ao final.

**Não implementado:** gráficos 3D realistas, câmeras 3D verdadeiras, login Google, salas online,
sincronização entre dois aparelhos, combate, animações e vitória por contato.
A demo não deve ser anunciada como jogo multiplayer pronto.

## Abrir no Android Studio (Windows)
1. Extraia o ZIP.
2. Abra Android Studio > Open > selecione esta pasta.
3. Use JDK 17, Android SDK 35 e Gradle 8.9.
4. O ZIP não contém `gradle-wrapper.jar`. Se o Android Studio solicitar Gradle,
   configure uma instalação local do Gradle 8.9 ou gere um wrapper a partir dessa instalação:
   `gradle wrapper --gradle-version 8.9`.
5. Aguarde Sync, conecte um celular Android com depuração USB e clique Run.
6. Para APK: Build > Build APK(s).

## Evolução necessária para o jogo solicitado
- Renderizador 3D (Godot ou engine 3D Android), modelos Bia/João, interiores e iluminação.
- Login Google Credential Manager + backend com verificação de token.
- Servidor autoritativo para 2 jogadores, salas com código, estados, colisão e resultados.
- Validação em aparelhos reais, latência e segurança.
- Hospedagem online poderá gerar custos.

## Revisão V2
- Movimento por eixos separado para deslizar ao longo de paredes.
- Colisão das casas revisada: abertura na parede inferior somente quando porta aberta.
- Mensagens de interação com duração limitada.
- Ainda não há motor 3D, autenticação ou rede: não foram falsamente declarados como corrigidos.
- Não há SDK Android/Gradle neste ambiente, portanto **não foi possível executar Build/Run**.
