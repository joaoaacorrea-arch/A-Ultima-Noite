package com.ultimanoite.game

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * DEMO LOCAL: renderização 2D estilizada. Não representa multiplayer online,
 * login Google ou gráficos 3D. A arquitetura de rede é uma etapa futura.
 */
class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(42)
    private val trees = List(85) { PointF(70f + rnd.nextFloat()*1800f, 90f+rnd.nextFloat()*950f) }
    private val houses = listOf(
        RectF(240f,180f,460f,370f), RectF(630f,160f,850f,360f),
        RectF(1080f,200f,1310f,390f), RectF(1500f,170f,1720f,360f),
        RectF(290f,660f,520f,870f), RectF(730f,690f,960f,900f),
        RectF(1180f,680f,1410f,890f), RectF(1550f,670f,1770f,880f)
    )
    private val doors = BooleanArray(8)
    private var px=970f; private var py=515f
    private var character="Bia"; private var killer=false
    private var cameraThird=false; private var started=false; private var finished=false
    private var seconds=180; private var startMs=0L
    private var lastFrame=System.nanoTime()
    private var lastTouchX=0f; private var lastTouchY=0f
    private var stickX=0f; private var stickY=0f
    private var touchId=-1
    private var currentWeapon=0
    private val weapons=listOf("Faca","Corda","Pedaço de pau")
    private var message="Explore as casas e a floresta"
    private var toastUntil=0L
    private val font=Typeface.create("sans-serif",Typeface.BOLD)

    private fun color(c:Long)=c.toInt()
    private fun rect(c:Canvas, l:Float,t:Float,r:Float,b:Float, col:Int, radius:Float=0f) {
        p.color=col;p.style=Paint.Style.FILL
        c.drawRoundRect(l,t,r,b,radius,radius,p)
    }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float=24f,col:Int=Color.WHITE) {
        p.color=col;p.textSize=size;p.typeface=font;p.style=Paint.Style.FILL
        c.drawText(s,x,y,p)
    }
    private fun circle(c:Canvas,x:Float,y:Float,r:Float,col:Int) {
        p.color=col;p.style=Paint.Style.FILL;c.drawCircle(x,y,r,p)
    }
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        val w=width.toFloat();val h=height.toFloat()
        canvas.drawColor(Color.rgb(8,15,24))
        if (!started || finished) { drawMenu(canvas,w,h); return }
        val now=System.nanoTime()
        val dt=((now-lastFrame)/1e9f).coerceIn(0f,0.04f);lastFrame=now
        val speed=if(killer) 190f else 205f
        val nx=(px+stickX*speed*dt).coerceIn(30f,1890f)
        val ny=(py+stickY*speed*dt).coerceIn(30f,1040f)
        if (!collides(nx,py)) px=nx
        if (!collides(px,ny)) py=ny
        val remaining=(seconds-(System.currentTimeMillis()-startMs)/1000).coerceAtLeast(0)
        if(remaining==0L){finished=true;message="Tempo esgotado: sobrevivente venceu!";invalidate();return}
        // Câmera aproximada = protótipo da perspectiva; NÃO é uma câmera 3D real.
        val scale=if(cameraThird) min(w/1100f,h/700f) else min(w/620f,h/400f)
        canvas.save()
        canvas.translate(w/2-px*scale,h/2-py*scale)
        canvas.scale(scale,scale)
        rect(canvas,0f,0f,1940f,1100f,Color.rgb(22,43,40))
        rect(canvas,0f,450f,1940f,620f,Color.rgb(68,65,59))
        rect(canvas,960f,0f,1060f,1100f,Color.rgb(68,65,59))
        for(t in trees) {
            circle(canvas,t.x+7,t.y+8,27f,Color.rgb(9,25,20))
            circle(canvas,t.x,t.y,25f,Color.rgb(19,70,49))
            circle(canvas,t.x-6,t.y-6,15f,Color.rgb(29,92,62))
        }
        houses.forEachIndexed { i,r->
            rect(canvas,r.left-7,r.top-7,r.right+7,r.bottom+7,Color.rgb(10,12,14),8f)
            rect(canvas,r.left,r.top,r.right,r.bottom,Color.rgb(85,76,69),5f)
            // Paredes e interior visível para permitir navegação nas casas.
            p.color=Color.rgb(174,157,127);p.style=Paint.Style.STROKE;p.strokeWidth=14f
            canvas.drawLine(r.left,r.top,r.right,r.top,p)
            canvas.drawLine(r.left,r.top,r.left,r.bottom,p)
            canvas.drawLine(r.right,r.top,r.right,r.bottom,p)
            val mid=(r.left+r.right)/2
            canvas.drawLine(r.left,r.bottom,mid-28,r.bottom,p)
            canvas.drawLine(mid+28,r.bottom,r.right,r.bottom,p)
            p.style=Paint.Style.FILL
            if(!doors[i]) rect(canvas,mid-26,r.bottom-8,mid+26,r.bottom+8,Color.rgb(119,67,39))
            else rect(canvas,mid+24,r.bottom-58,mid+34,r.bottom+3,Color.rgb(139,86,51))
            rect(canvas,r.left+22,r.top+26,r.left+70,r.top+62,Color.rgb(57,43,40),5f)
            rect(canvas,r.right-65,r.bottom-75,r.right-20,r.bottom-25,Color.rgb(65,55,49),5f)
        }
        circle(canvas,px+5,py+7,20f,Color.rgb(4,8,13))
        circle(canvas,px,py,17f,if(killer)Color.rgb(178,48,60) else Color.rgb(80,173,220))
        text(canvas,character,px-28,py-28,18f)
        canvas.restore()
        rect(canvas,12f,10f,w-12,68f,Color.argb(195,8,13,24),12f)
        text(canvas,"A ÚLTIMA NOITE",27f,44f,25f)
        text(canvas,"%02d:%02d".format(remaining/60,remaining%60),w/2-44,45f,28f)
        text(canvas,if(killer)"ASSASSINO" else "SOBREVIVENTE",w-195,43f,20f)
        // joystick
        circle(canvas,100f,h-105,76f,Color.argb(110,210,220,240))
        circle(canvas,100+stickX*40,h-105+stickY*40,34f,Color.argb(210,110,166,228))
        val bx=w-135
        rect(canvas,bx-20,h-166,bx+120,h-108,Color.argb(205,35,46,66),16f)
        text(canvas,if(cameraThird)"1ª PESSOA" else "3ª PESSOA",bx-7,h-130,17f)
        rect(canvas,bx-20,h-94,bx+120,h-35,Color.argb(205,62,76,60),16f)
        text(canvas,"PORTA",bx+14,h-57,22f)
        if(killer){
            rect(canvas,w/2-100,h-62,w/2+100,h-14,Color.argb(215,92,36,43),13f)
            text(canvas,weapons[currentWeapon],w/2-82,h-30,20f)
        }
        if(System.currentTimeMillis()<toastUntil) text(canvas,message,180f,h-22,17f,Color.rgb(226,232,237))
        postInvalidateDelayed(16)
    }
    private fun collides(x:Float,y:Float):Boolean {
        // Uma casa só pode ser atravessada pela abertura da porta.
        houses.forEachIndexed { i,r ->
            if(x>r.left-12 && x<r.right+12 && y>r.top-12 && y<r.bottom+12) {
                val pad=17f
                val insideNow=px>r.left+pad && px<r.right-pad && py>r.top+pad && py<r.bottom-pad
                val insideNext=x>r.left+pad && x<r.right-pad && y>r.top+pad && y<r.bottom-pad
                if(insideNow && insideNext) return@forEachIndexed
                val doorX=(r.left+r.right)/2
                // Permite cruzar apenas a abertura inferior quando a porta está aberta.
                if (doors[i] && abs(x-doorX)<20f && abs(px-doorX)<20f &&
                    y>r.bottom-38f && py>r.bottom-38f) return@forEachIndexed
                return true
            }
        }
        return false
    }
    private fun drawMenu(c:Canvas,w:Float,h:Float) {
        val grad=LinearGradient(0f,0f,w,h,Color.rgb(9,22,35),Color.rgb(30,45,40),Shader.TileMode.CLAMP)
        p.shader=grad;c.drawRect(0f,0f,w,h,p);p.shader=null
        text(c,"ESCONDE-ESCONDE",w*.25f,h*.23f,40f)
        text(c,"A ÚLTIMA NOITE",w*.31f,h*.32f,34f,Color.rgb(200,214,231))
        if(finished) text(c,message,w*.22f,h*.43f,22f)
        val y=h*.49f
        rect(c,w*.18f,y,w*.42f,y+56,if(character=="Bia")Color.rgb(76,110,150) else Color.rgb(40,57,72),12f)
        rect(c,w*.48f,y,w*.72f,y+56,if(character=="João")Color.rgb(76,110,150) else Color.rgb(40,57,72),12f)
        text(c,"BIA",w*.27f,y+36,24f);text(c,"JOÃO",w*.57f,y+36,24f)
        rect(c,w*.18f,y+72,w*.42f,y+128,if(killer)Color.rgb(112,48,58) else Color.rgb(40,57,72),12f)
        rect(c,w*.48f,y+72,w*.72f,y+128,if(!killer)Color.rgb(52,105,88) else Color.rgb(40,57,72),12f)
        text(c,"ASSASSINO",w*.205f,y+108,19f);text(c,"VÍTIMA",w*.56f,y+108,20f)
        rect(c,w*.18f,y+146,w*.72f,y+202,Color.rgb(53,67,89),12f)
        text(c,"DURAÇÃO: ${seconds/60} MIN  (TOQUE PARA ALTERAR)",w*.22f,y+181,18f)
        rect(c,w*.3f,y+220,w*.6f,y+279,Color.rgb(51,118,95),14f)
        text(c,"JOGAR DEMO LOCAL",w*.32f,y+257,21f)
        text(c,"Protótipo offline • Login Google e multiplayer ainda não integrados",w*.18f,h-15,15f)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        val w=width.toFloat();val h=height.toFloat()
        val idx=e.actionIndex
        val x=e.getX(idx);val y=e.getY(idx)
        if(e.actionMasked==MotionEvent.ACTION_DOWN || e.actionMasked==MotionEvent.ACTION_POINTER_DOWN) {
            if(!started || finished) {
                val top=h*.49f
                if(y in top..(top+56)){character=if(x<w*.45f)"Bia" else "João"}
                else if(y in (top+72)..(top+128)){killer=x<w*.45f}
                else if(y in (top+146)..(top+202)){seconds=when(seconds){180->300;300->420;else->180}}
                else if(y in (top+220)..(top+279)){started=true;finished=false;startMs=System.currentTimeMillis();lastFrame=System.nanoTime();message="Explore o cenário";toastUntil=System.currentTimeMillis()+3000}
            } else if(x<190 && y>h-205) {touchId=e.getPointerId(idx);stickX=((x-100)/70).coerceIn(-1f,1f);stickY=((y-(h-105))/70).coerceIn(-1f,1f)}
            else if(x>w-155 && y>h-180 && y<h-100) cameraThird=!cameraThird
            else if(x>w-155 && y>h-100) {
                val nearest=houses.indices.minByOrNull { i ->
                    val r=houses[i];hypot((r.left+r.right)/2-px.toDouble(),r.bottom-py.toDouble())
                } ?: 0
                val r=houses[nearest]
                if(hypot((r.left+r.right)/2-px.toDouble(),r.bottom-py.toDouble())<125) {
                    doors[nearest]=!doors[nearest]
                    message=if(doors[nearest])"Porta aberta" else "Porta fechada";toastUntil=System.currentTimeMillis()+2500
                } else { message="Aproxime-se de uma porta";toastUntil=System.currentTimeMillis()+2500 }
            } else if(killer && y>h-80 && x>w/2-120 && x<w/2+120) currentWeapon=(currentWeapon+1)%3
            invalidate()
        } else if(e.actionMasked==MotionEvent.ACTION_MOVE && touchId!=-1) {
            val i=(0 until e.pointerCount).firstOrNull {e.getPointerId(it)==touchId}
            if(i!=null){stickX=((e.getX(i)-100)/70).coerceIn(-1f,1f);stickY=((e.getY(i)-(h-105))/70).coerceIn(-1f,1f)}
        } else if(e.actionMasked==MotionEvent.ACTION_UP || e.actionMasked==MotionEvent.ACTION_POINTER_UP || e.actionMasked==MotionEvent.ACTION_CANCEL) {
            if(e.actionMasked==MotionEvent.ACTION_CANCEL || e.getPointerId(idx)==touchId){touchId=-1;stickX=0f;stickY=0f}
        }
        return true
    }
}
