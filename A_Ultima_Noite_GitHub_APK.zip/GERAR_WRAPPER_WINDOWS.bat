@echo off
where gradle >nul 2>&1
if errorlevel 1 (echo Instale Gradle 8.9 ou use Android Studio para sincronizar. & pause & exit /b 1)
gradle wrapper --gradle-version 8.9
pause
