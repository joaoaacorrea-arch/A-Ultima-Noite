extends CharacterBody3D

var player_id := 1
var character := 0
var display_name := "Jogador"
var head: Node3D
var first_camera: Camera3D
var third_camera: Camera3D
var visual: Node3D
var first_person := true
var crouching := false
var touch_look := -1
var touch_move := -1
var move_start := Vector2.ZERO
var touch_direction := Vector2.ZERO
var previous_crouch := false

func _piece(pos: Vector3, dimensions: Vector3, color: Color, sphere := false) -> void:
	var instance := MeshInstance3D.new()
	if sphere:
		var shape := SphereMesh.new()
		shape.radius = dimensions.x
		shape.height = dimensions.y
		shape.radial_segments = 12
		shape.rings = 6
		instance.mesh = shape
	else:
		var shape := BoxMesh.new()
		shape.size = dimensions
		instance.mesh = shape
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	instance.material_override = material
	instance.position = pos
	visual.add_child(instance)

func _ready() -> void:
	floor_snap_length = 0.35
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.3
	capsule.height = 1.8
	collision.shape = capsule
	add_child(collision)
	visual = Node3D.new()
	add_child(visual)
	var outfit := Color("9d587d") if character == 0 else Color("3d678b")
	_piece(Vector3(0,0.05,0),Vector3(0.52,0.65,0.3),outfit)
	_piece(Vector3(0,0.63,0),Vector3(0.23,0.46,0),Color("d4ac91"),true)
	_piece(Vector3(0,0.79,0.05),Vector3(0.25,0.2,0),Color("271d26"),true)
	if character == 0: _piece(Vector3(0,0.48,0.23),Vector3(0.16,0.45,0),Color("271d26"),true)
	for side in [-1,1]:
		_piece(Vector3(side*0.37,0.0,0),Vector3(0.17,0.66,0.19),outfit)
		_piece(Vector3(side*0.16,-0.56,0),Vector3(0.21,0.65,0.23),Color("242c3e"))
		_piece(Vector3(side*0.16,-0.87,-0.08),Vector3(0.25,0.12,0.4),Color("171c26"))
	head = Node3D.new()
	head.position.y = 0.65
	add_child(head)
	first_camera = Camera3D.new()
	first_camera.fov = 75
	first_camera.near = 0.08
	head.add_child(first_camera)
	var spring := SpringArm3D.new()
	spring.spring_length = 3.3
	spring.position.y = 0.45
	spring.collision_mask = 1
	spring.add_excluded_object(get_rid())
	head.add_child(spring)
	third_camera = Camera3D.new()
	third_camera.fov = 75
	spring.add_child(third_camera)
	update_camera()

func is_local_player() -> bool:
	return player_id == multiplayer.get_unique_id()

func toggle_camera() -> void:
	first_person = not first_person
	update_camera()

func update_camera() -> void:
	if not is_inside_tree(): return
	if is_local_player():
		if first_person: first_camera.make_current()
		else: third_camera.make_current()
	visual.visible = not (is_local_player() and first_person)

func reset_input() -> void:
	touch_move = -1
	touch_look = -1
	touch_direction = Vector2.ZERO

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: reset_input()

func _unhandled_input(event: InputEvent) -> void:
	if not is_local_player() or not get_parent().running: return
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < 500 and touch_move == -1:
				touch_move = event.index
				move_start = event.position
			elif touch_look == -1: touch_look = event.index
		else:
			if event.index == touch_move:
				touch_move = -1
				touch_direction = Vector2.ZERO
			if event.index == touch_look: touch_look = -1
	elif event is InputEventScreenDrag:
		if event.index == touch_move: touch_direction = (event.position-move_start).limit_length(85)/85
		if event.index == touch_look:
			rotation.y -= event.relative.x*0.004
			head.rotation.x = clampf(head.rotation.x-event.relative.y*0.004,-1.2,1.2)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		rotation.y -= event.relative.x*0.003
		head.rotation.x = clampf(head.rotation.x-event.relative.y*0.003,-1.2,1.2)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_E: get_parent()._interact()
		elif event.keycode == KEY_C: toggle_camera()

func _physics_process(delta: float) -> void:
	if crouching != previous_crouch:
		head.position.y = 0.2 if crouching else 0.65
		visual.scale.y = 0.72 if crouching else 1.0
		previous_crouch = crouching
	if not is_local_player() or not get_parent().running: return
	if not is_on_floor(): velocity.y -= 18*delta
	var movement := Input.get_vector("ui_left","ui_right","ui_up","ui_down") + touch_direction
	movement.x += float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A))
	movement.y += float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W))
	movement = movement.limit_length()
	var direction := transform.basis*Vector3(movement.x,0,movement.y)
	var speed := 2.0 if crouching else 4.0
	velocity.x = direction.x*speed
	velocity.z = direction.z*speed
	move_and_slide()
	position.x = clampf(position.x,-53,53)
	position.z = clampf(position.z,-53,53)
