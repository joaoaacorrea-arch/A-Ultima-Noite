extends Node3D

const PORT := 24567
const PLAYER = preload("res://scripts/player.gd")
const WEAPONS := ["Faca", "Corda", "Pedaço de pau"]
var peer: ENetMultiplayerPeer
var players: Dictionary = {}
var running := false
var solo := false
var remaining := 180.0
var match_seconds := 180
var local_player: CharacterBody3D
var world: Node3D
var menu: PanelContainer
var status: Label
var info: Label
var name_edit: LineEdit
var address_edit: LineEdit
var character_option: OptionButton
var role_option: OptionButton
var duration_option: OptionButton
var hud: Control
var weapon_button: Button
var attack_button: Button
var crouch_button: Button
var weapon_index := 0
var preview_camera: Camera3D
var net_timer := 0.0
var clock_timer := 0.0
var last_attack := -10.0
var joystick: Control

func _ready() -> void:
	world = preload("res://scripts/scenery.gd").new()
	add_child(world)
	preview_camera = Camera3D.new()
	preview_camera.position = Vector3(0,16,26)
	add_child(preview_camera)
	preview_camera.look_at(Vector3(0,1,-12))
	preview_camera.current = true
	_build_ui()
	multiplayer.peer_connected.connect(_peer_connected)
	multiplayer.peer_disconnected.connect(_peer_disconnected)
	multiplayer.connected_to_server.connect(_connected)
	multiplayer.connection_failed.connect(func(): info.text = "Não foi possível conectar. Confira o IP e o Wi-Fi.")
	multiplayer.server_disconnected.connect(_server_disconnected)

func _style(bg: Color, border: Color, radius := 14) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s

func _button(text_value: String, parent: Node, action: Callable) -> Button:
	var b := Button.new()
	b.text = text_value
	b.custom_minimum_size.y = 45
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func _label(text_value: String, parent: Node, size := 18) -> Label:
	var l := Label.new()
	l.text = text_value
	l.add_theme_font_size_override("font_size",size)
	parent.add_child(l)
	return l

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var theme := Theme.new()
	theme.default_font_size = 18
	theme.set_stylebox("normal","Button",_style(Color("172b35"),Color("375b66")))
	theme.set_stylebox("hover","Button",_style(Color("25434b"),Color("80c3b0")))
	theme.set_stylebox("pressed","Button",_style(Color("37665e"),Color("b7e0ce")))
	theme.set_stylebox("normal","LineEdit",_style(Color("0c1822"),Color("375b66")))
	theme.set_stylebox("panel","PanelContainer",_style(Color(0.025,0.05,0.08,0.96),Color("547b79"),20))
	menu = PanelContainer.new()
	menu.theme = theme
	layer.add_child(menu)
	menu.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	menu.position = Vector2(36,26)
	menu.size = Vector2(440,650)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation",7)
	menu.add_child(v)
	_label("ESCONDE-ESCONDE",v,18).modulate = Color("a2c7bd")
	_label("A ÚLTIMA NOITE",v,32)
	_label("Vila abandonada · protótipo 3D",v,15)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Seu nome"
	name_edit.text = "Jogador"
	name_edit.max_length = 24
	v.add_child(name_edit)
	var row := HBoxContainer.new()
	v.add_child(row)
	character_option = OptionButton.new()
	character_option.add_item("Bia")
	character_option.add_item("João")
	character_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(character_option)
	role_option = OptionButton.new()
	role_option.add_item("Sobrevivente")
	role_option.add_item("Assassino")
	role_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(role_option)
	duration_option = OptionButton.new()
	for minutes in [3,5,7]: duration_option.add_item("Partida de %d minutos" % minutes)
	v.add_child(duration_option)
	_button("EXPLORAR A VILA · SOZINHO",v,_explore)
	_label("DOIS JOGADORES NA MESMA REDE",v,14).modulate = Color("a2c7bd")
	address_edit = LineEdit.new()
	address_edit.placeholder_text = "IP do anfitrião · ex.: 192.168.1.20"
	v.add_child(address_edit)
	var buttons := HBoxContainer.new()
	v.add_child(buttons)
	_button("Criar sala",buttons,_host).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_button("Entrar",buttons,_join).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_button("INICIAR PARTIDA · ANFITRIÃO",v,_start_match)
	info = _label("Escolha um personagem e explore a vila.",v,15)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(390,60)
	_label("Login Google e salas pela internet: não disponíveis.",v,12)
	_label("Godot Engine · godotengine.org/license",v,12)
	status = _label("Vila abandonada · noite de lua cheia",layer,20)
	status.position = Vector2(500,28)
	hud = Control.new()
	hud.theme = theme
	layer.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_button("CÂMERA 1ª / 3ª",Vector2(-205,75),func(): if local_player: local_player.toggle_camera())
	_hud_button("ABRIR / FECHAR PORTA",Vector2(-205,140),_interact)
	crouch_button = _hud_button("AGACHAR",Vector2(-205,205),_crouch)
	attack_button = _hud_button("ATACAR",Vector2(-205,270),_attack)
	weapon_button = _hud_button("Arma: Faca",Vector2(-205,335),_cycle_weapon)
	_hud_button("VOLTAR AO MENU",Vector2(-205,405),_leave)
	joystick = preload("res://scripts/joystick.gd").new()
	hud.add_child(joystick)
	_label("Arraste à esquerda para andar · à direita para olhar",hud,16).position = Vector2(30,675)
	hud.hide()

func _hud_button(text_value: String, offset: Vector2, action: Callable) -> Button:
	var b := _button(text_value,hud,action)
	b.add_theme_font_size_override("font_size",14)
	b.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	b.offset_left = offset.x
	b.offset_right = offset.x + 185
	b.offset_top = offset.y
	b.offset_bottom = offset.y + 52
	return b

func _reset() -> void:
	running = false
	local_player = null
	for child in get_children():
		if child is CharacterBody3D:
			remove_child(child)
			child.queue_free()
	players.clear()
	if peer:
		peer.close()
	peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	world.reset_doors()
	preview_camera.current = true
	hud.hide()
	menu.show()
	last_attack = -10.0

func _leave() -> void:
	_reset()
	info.text = "Escolha explorar sozinho ou criar uma nova sala."
	status.text = "Vila abandonada · noite de lua cheia"

func _explore() -> void:
	_reset()
	solo = true
	players[1] = {"name":name_edit.text,"character":character_option.selected,"role":role_option.selected}
	_spawn(1)
	running = true
	menu.hide()
	status.text = "EXPLORAÇÃO · entre nas casas e conheça a vila"

func _host() -> void:
	_reset()
	solo = false
	peer = ENetMultiplayerPeer.new()
	var error := peer.create_server(PORT,1)
	if error != OK:
		info.text = "Falha ao criar sala: %s" % error
		return
	multiplayer.multiplayer_peer = peer
	match_seconds = [180,300,420][duration_option.selected]
	players[1] = {"name":name_edit.text,"character":character_option.selected,"role":role_option.selected}
	_spawn(1)
	var addresses: Array[String] = []
	for address in IP.get_local_addresses():
		if address.begins_with("192.168.") or address.begins_with("10.") or address.begins_with("172."):
			addresses.append(address)
	info.text = "Sala criada. IP: %s · UDP %d. Aguardando outro jogador." % [", ".join(addresses),PORT]

func _join() -> void:
	var address := address_edit.text.strip_edges()
	if address.is_empty():
		info.text = "Digite o IP do anfitrião."
		return
	_reset()
	solo = false
	peer = ENetMultiplayerPeer.new()
	var error := peer.create_client(address,PORT)
	if error != OK:
		info.text = "Falha de conexão: %s" % error
		return
	multiplayer.multiplayer_peer = peer
	info.text = "Conectando ao anfitrião..."

func _connected() -> void:
	register_player.rpc_id(1,name_edit.text,character_option.selected,role_option.selected)

func _peer_connected(_id: int) -> void:
	pass

@rpc("any_peer","reliable")
func register_player(display_name: String,character: int,role: int) -> void:
	if not multiplayer.is_server() or solo: return
	var id := multiplayer.get_remote_sender_id()
	if id <= 1 or players.has(id): return
	if players.size() != 1 or character not in [0,1] or role not in [0,1]: return
	if players[1]["character"] == character or players[1]["role"] == role:
		reject_player.rpc_id(id,"Escolha o outro personagem e o papel oposto ao anfitrião.")
		return
	players[id] = {"name":display_name.left(24),"character":character,"role":role}
	_spawn(id)
	update_roster.rpc(players)
	info.text = "Dois jogadores conectados. Toque em INICIAR PARTIDA."

@rpc("authority","reliable")
func reject_player(message: String) -> void:
	_reset()
	info.text = message

@rpc("authority","reliable")
func update_roster(roster: Dictionary) -> void:
	players = roster
	for id in players: _spawn(id)
	info.text = "Conectado. Aguardando o anfitrião iniciar."

func _spawn(id: int) -> void:
	if has_node("Player_%d" % id): return
	var actor := PLAYER.new()
	actor.name = "Player_%d" % id
	actor.player_id = id
	actor.character = int(players[id]["character"])
	actor.display_name = str(players[id]["name"])
	actor.position = Vector3(-1.5,1.0,12) if players[id]["role"] == 0 else Vector3(1.5,1.0,-12)
	add_child(actor)
	if id == multiplayer.get_unique_id():
		local_player = actor
		preview_camera.current = false
		actor.update_camera()
		attack_button.visible = players[id]["role"] == 1
		weapon_button.visible = attack_button.visible

func _start_match() -> void:
	if solo or not peer or not multiplayer.is_server():
		info.text = "Crie a sala como anfitrião primeiro."
		return
	if players.size() != 2:
		info.text = "Aguardando o segundo jogador. Use personagens e papéis diferentes."
		return
	start_round.rpc(match_seconds)

@rpc("authority","call_local","reliable")
func start_round(seconds: int) -> void:
	remaining = float(seconds)
	running = true
	menu.hide()
	hud.show()
	if local_player: local_player.update_camera()

func _peer_disconnected(id: int) -> void:
	players.erase(id)
	var actor := get_node_or_null("Player_%d" % id)
	if actor:
		remove_child(actor)
		actor.queue_free()
	running = false
	hud.hide()
	menu.show()
	info.text = "Jogador desconectou. Crie uma nova sala."

func _server_disconnected() -> void:
	_reset()
	info.text = "Conexão com o anfitrião encerrada."

func _process(delta: float) -> void:
	if not running: return
	if not hud.visible: hud.show()
	if solo: return
	if multiplayer.is_server():
		remaining = maxf(0.0,remaining-delta)
		if remaining <= 0.0: _finish("Sobrevivente venceu por tempo!")
	status.text = "%02d:%02d · %s · LAN" % [int(remaining)/60,int(remaining)%60,"ASSASSINO" if players.get(multiplayer.get_unique_id(),{}).get("role",0) == 1 else "SOBREVIVENTE"]

func _physics_process(delta: float) -> void:
	if not running or solo or not peer or not local_player: return
	net_timer += delta
	clock_timer += delta
	if net_timer >= 0.05:
		net_timer = 0.0
		if multiplayer.is_server():
			sync_actor.rpc(1,local_player.position,local_player.rotation.y,local_player.head.rotation.x,local_player.crouching)
		else:
			submit_pose.rpc_id(1,local_player.position,local_player.rotation.y,local_player.head.rotation.x,local_player.crouching)
	if multiplayer.is_server() and clock_timer >= 0.5:
		clock_timer = 0.0
		sync_clock.rpc(remaining)

@rpc("any_peer","call_remote","unreliable_ordered",1)
func submit_pose(pos: Vector3,yaw: float,pitch: float,crouched: bool) -> void:
	if not multiplayer.is_server() or not running: return
	var id := multiplayer.get_remote_sender_id()
	if not players.has(id) or not pos.is_finite() or not is_finite(yaw) or not is_finite(pitch): return
	var actor := get_node_or_null("Player_%d" % id)
	if not actor or actor.position.distance_to(pos) > 5.0 or absf(pos.x) > 54 or absf(pos.z) > 54: return
	actor.position = pos
	actor.rotation.y = yaw
	actor.head.rotation.x = clampf(pitch,-1.2,1.2)
	actor.crouching = crouched
	sync_actor.rpc(id,pos,yaw,pitch,crouched)

@rpc("authority","call_remote","unreliable_ordered",1)
func sync_actor(id: int,pos: Vector3,yaw: float,pitch: float,crouched: bool) -> void:
	if id == multiplayer.get_unique_id(): return
	var actor := get_node_or_null("Player_%d" % id)
	if actor:
		actor.position = pos
		actor.rotation.y = yaw
		actor.head.rotation.x = pitch
		actor.crouching = crouched

@rpc("authority","call_remote","unreliable_ordered",2)
func sync_clock(seconds: float) -> void:
	remaining = seconds

func _interact() -> void:
	if not local_player or not running: return
	if solo or multiplayer.is_server(): _try_door(multiplayer.get_unique_id())
	else: request_door.rpc_id(1)

@rpc("any_peer","reliable")
func request_door() -> void:
	if multiplayer.is_server() and running: _try_door(multiplayer.get_remote_sender_id())

func _try_door(id: int) -> void:
	var actor := get_node_or_null("Player_%d" % id)
	if not actor: return
	var index: int = world.nearest_door(actor.position)
	if index < 0: return
	var opened: bool = not world.door_states[index]
	if not opened:
		for player_id in players:
			var other := get_node_or_null("Player_%d" % player_id)
			if other and other.position.distance_to(world.door_point(index)) < 1.8: return
	if solo: world.set_door(index,opened)
	else: sync_door.rpc(index,opened)

@rpc("authority","call_local","reliable")
func sync_door(index: int,opened: bool) -> void:
	world.set_door(index,opened)

func _crouch() -> void:
	if local_player:
		local_player.crouching = not local_player.crouching
		crouch_button.text = "LEVANTAR" if local_player.crouching else "AGACHAR"

func _cycle_weapon() -> void:
	weapon_index = (weapon_index+1) % WEAPONS.size()
	weapon_button.text = "Arma: " + WEAPONS[weapon_index]

func _attack() -> void:
	if solo: return
	if multiplayer.is_server(): _validate_attack(1,weapon_index)
	else: request_attack.rpc_id(1,weapon_index)

@rpc("any_peer","reliable")
func request_attack(weapon: int) -> void:
	if multiplayer.is_server(): _validate_attack(multiplayer.get_remote_sender_id(),weapon)

func _validate_attack(id: int,weapon: int) -> void:
	if not running or not players.has(id) or players[id]["role"] != 1 or weapon not in [0,1,2]: return
	var now := Time.get_ticks_msec()/1000.0
	if now-last_attack < 0.7: return
	last_attack = now
	var attacker := get_node_or_null("Player_%d" % id)
	if not attacker: return
	for victim_id in players:
		if players[victim_id]["role"] != 0: continue
		var victim := get_node_or_null("Player_%d" % victim_id)
		if not victim or attacker.position.distance_to(victim.position) > 2.3: continue
		var query := PhysicsRayQueryParameters3D.create(attacker.position+Vector3.UP*0.4,victim.position+Vector3.UP*0.4,1,[attacker.get_rid()])
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if hit.is_empty() or hit.get("collider") == victim: _finish("Assassino venceu · " + WEAPONS[weapon])

func _finish(message: String) -> void:
	if running: end_round.rpc(message)

@rpc("authority","call_local","reliable")
func end_round(message: String) -> void:
	running = false
	hud.hide()
	menu.show()
	info.text = message + "\nCrie outra sala para jogar novamente."
	status.text = message
