extends Control

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _process(_delta: float) -> void:
	queue_redraw()

func _draw() -> void:
	var main := get_parent().get_parent().get_parent()
	var actor: CharacterBody3D = main.local_player
	var center := Vector2(115,570)
	var offset := Vector2.ZERO
	if actor and actor.touch_move >= 0:
		center = actor.move_start
		offset = actor.touch_direction*55
	draw_circle(center,78,Color(0.1,0.2,0.24,0.6))
	draw_arc(center,78,0,TAU,40,Color(0.6,0.8,0.75,0.65),2,true)
	draw_circle(center+offset,29,Color(0.6,0.8,0.75,0.8))
