extends Node3D
# Cenário procedural, sem assets externos. Criado para rodar no renderizador Compatibility.
var rng := RandomNumberGenerator.new()
var mats := {}
var doors: Array[Node3D] = []
var door_states: Array[bool] = []

func _mat(key: String, color: Color, rough := 1.0, emission := false) -> StandardMaterial3D:
 if mats.has(key): return mats[key]
 var m := StandardMaterial3D.new()
 m.albedo_color = color
 m.roughness = rough
 if emission:
  m.emission_enabled = true
  m.emission = color
  m.emission_energy_multiplier = 2.2
 mats[key] = m
 return m

func _box(pos: Vector3, size: Vector3, material: Material, solid := true, rot := Vector3.ZERO) -> Node3D:
 var root: Node3D = StaticBody3D.new() if solid else Node3D.new()
 root.position = pos
 root.rotation = rot
 add_child(root)
 var mesh := MeshInstance3D.new()
 var b := BoxMesh.new()
 b.size = size
 mesh.mesh = b
 mesh.material_override = material
 root.add_child(mesh)
 if solid:
  var collision := CollisionShape3D.new()
  var shape := BoxShape3D.new()
  shape.size = size
  collision.shape = shape
  root.add_child(collision)
 return root

func _cylinder(pos: Vector3, radius: float, height: float, material: Material, solid := false) -> void:
 var node := MeshInstance3D.new()
 var mesh := CylinderMesh.new()
 mesh.top_radius = radius * 0.7
 mesh.bottom_radius = radius
 mesh.height = height
 mesh.radial_segments = 6
 node.mesh = mesh
 node.material_override = material
 node.position = pos
 add_child(node)
 if solid:
  var body := StaticBody3D.new()
  body.position = pos
  var cs := CollisionShape3D.new()
  var shape := CylinderShape3D.new()
  shape.radius = radius
  shape.height = height
  cs.shape = shape
  body.add_child(cs)
  add_child(body)

func _tree(x: float, z: float, scale_factor: float) -> void:
 var trunk := _mat("bark",Color(0.16,0.12,0.105))
 var pine := _mat("pine",Color(0.055,0.115,0.105))
 var pine2 := _mat("pine2",Color(0.085,0.15,0.125))
 var h := 4.0 * scale_factor
 _cylinder(Vector3(x,h*0.5,z),0.25*scale_factor,h,trunk,true)
 for level in range(3):
  var cone := MeshInstance3D.new()
  var mesh := CylinderMesh.new()
  mesh.top_radius = 0.02
  mesh.bottom_radius = (1.75 - level*0.3)*scale_factor
  mesh.height = 2.6*scale_factor
  mesh.radial_segments = 7
  cone.mesh = mesh
  cone.material_override = pine if level % 2 == 0 else pine2
  cone.position = Vector3(x,(3.7+level*1.1)*scale_factor,z)
  add_child(cone)

func _cabin(center: Vector3, index: int) -> void:
 var wood := _mat("wood",Color(0.22,0.17,0.14))
 var dark := _mat("darkwood",Color(0.11,0.10,0.105))
 var roof := _mat("roof",Color(0.115,0.14,0.16))
 var glass := _mat("glass",Color(0.12,0.18,0.20),0.2)
 var glow := _mat("lantern",Color(1.0,0.48,0.15),0.5,true)
 var root := Node3D.new()
 root.position = center
 root.rotation.y = float(index % 4) * PI / 2.0
 add_child(root)
 # Build geometry as child nodes so whole house can be rotated.
 var parts := [
  [Vector3(0,1.55,-3.3),Vector3(8,3.1,0.35),wood],
  [Vector3(-4,1.55,0),Vector3(0.35,3.1,6.6),wood],
  [Vector3(4,1.55,0),Vector3(0.35,3.1,6.6),wood],
  [Vector3(-2.7,1.55,3.3),Vector3(2.6,3.1,0.35),wood],
  [Vector3(2.7,1.55,3.3),Vector3(2.6,3.1,0.35),wood],
  [Vector3(0,2.75,3.3),Vector3(2.8,0.7,0.35),wood],
  [Vector3(0,3.45,-1.65),Vector3(8.7,0.35,4.3),roof],
  [Vector3(0,3.45,1.65),Vector3(8.7,0.35,4.3),roof],
  [Vector3(0,-0.1,0),Vector3(8.4,0.24,7),dark],
  [Vector3(-2.1,1.75,3.51),Vector3(1.15,1.2,0.06),glass],
  [Vector3(2.1,1.75,3.51),Vector3(1.15,1.2,0.06),glass],
  [Vector3(0,2.3,3.53),Vector3(0.9,0.12,0.1),dark]
 ]
 for item in parts:
  var p := StaticBody3D.new()
  p.position = item[0]
  var mi := MeshInstance3D.new()
  var bm := BoxMesh.new()
  bm.size = item[1]
  mi.mesh = bm
  mi.material_override = item[2]
  p.add_child(mi)
  var cs := CollisionShape3D.new()
  var bs := BoxShape3D.new()
  bs.size = item[1]
  cs.shape = bs
  p.add_child(cs)
  root.add_child(p)
 for side in [-1,1]:
  var beam := MeshInstance3D.new()
  var bm := BoxMesh.new()
  bm.size = Vector3(5.2,0.28,7.2)
  beam.mesh = bm
  beam.material_override = roof
  beam.position = Vector3(side*2.15,4.1,0)
  beam.rotation.z = -side*0.55
  root.add_child(beam)
 var hinge := StaticBody3D.new()
 hinge.position = Vector3(-1.35,1.2,3.3)
 root.add_child(hinge)
 var door_mesh := MeshInstance3D.new()
 var door_box := BoxMesh.new()
 door_box.size = Vector3(2.7,2.4,0.14)
 door_mesh.mesh = door_box
 door_mesh.material_override = dark
 door_mesh.position.x = 1.35
 hinge.add_child(door_mesh)
 var door_collision := CollisionShape3D.new()
 var door_shape := BoxShape3D.new()
 door_shape.size = Vector3(2.7,2.4,0.14)
 door_collision.shape = door_shape
 door_collision.position.x = 1.35
 hinge.add_child(door_collision)
 doors.append(hinge)
 door_states.append(false)
 var lamp := OmniLight3D.new()
 lamp.position = Vector3(1.3,2.65,3.85)
 lamp.light_color = Color(1,0.55,0.28)
 lamp.light_energy = 1.25
 lamp.omni_range = 7.0
 lamp.shadow_enabled = false
 root.add_child(lamp)
 var bulb := MeshInstance3D.new()
 var sphere := SphereMesh.new()
 sphere.radius = 0.13
 sphere.height = 0.26
 bulb.mesh = sphere
 bulb.material_override = glow
 bulb.position = lamp.position
 root.add_child(bulb)

func _ready() -> void:
 rng.seed = 31072026
 _box(Vector3(0,-0.6,0),Vector3(110,1.2,110),_mat("ground",Color(0.095,0.14,0.12)))
 _box(Vector3(0,0.035,0),Vector3(6,0.08,95),_mat("road",Color(0.14,0.13,0.13)),false)
 for i in range(8):
  _cabin(Vector3(-11 if i % 2 == 0 else 11,0,-29 + (i / 2)*19),i)
 for i in range(155):
  var x := rng.randf_range(-53,53)
  var z := rng.randf_range(-53,53)
  if absf(x) < 19 and z > -39 and z < 39: continue
  _tree(x,z,rng.randf_range(0.8,1.55))
 var stone := _mat("stone",Color(0.16,0.19,0.19))
 for i in range(70):
  var x := rng.randf_range(-48,48)
  var z := rng.randf_range(-48,48)
  if absf(x) < 3.5: continue
  _box(Vector3(x,0.12,z),Vector3(rng.randf_range(0.25,0.8),0.24,rng.randf_range(0.3,0.8)),stone,false)
 var light := DirectionalLight3D.new()
 light.rotation_degrees = Vector3(-55,-28,0)
 light.light_color = Color(0.48,0.63,1.0)
 light.light_energy = 0.55
 light.shadow_enabled = false
 add_child(light)
 var moon := MeshInstance3D.new()
 var moon_mesh := SphereMesh.new()
 moon_mesh.radius = 3.2
 moon_mesh.height = 6.4
 moon_mesh.radial_segments = 24
 moon_mesh.rings = 12
 moon.mesh = moon_mesh
 var moon_mat := StandardMaterial3D.new()
 moon_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 moon_mat.albedo_color = Color(0.78,0.85,0.95)
 moon.mesh = moon_mesh
 moon.material_override = moon_mat
 moon.position = Vector3(-22,34,-48)
 add_child(moon)
 var world_env := WorldEnvironment.new()
 var env := Environment.new()
 env.background_mode = Environment.BG_COLOR
 env.background_color = Color(0.018,0.027,0.055)
 env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color = Color(0.19,0.25,0.34)
 env.ambient_light_energy = 0.8
 env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
 env.fog_enabled = true
 env.fog_light_color = Color(0.10,0.16,0.22)
 env.fog_density = 0.016
 world_env.environment = env
 add_child(world_env)

func door_point(index: int) -> Vector3:
 return doors[index].get_parent().to_global(Vector3(0,1.2,3.3))

func nearest_door(pos: Vector3) -> int:
 var selected := -1
 var distance := 4.0
 for i in doors.size():
  var d := pos.distance_to(door_point(i))
  if d < distance:
   selected = i
   distance = d
 return selected

func set_door(index: int, opened: bool) -> void:
 if index < 0 or index >= doors.size(): return
 door_states[index] = opened
 doors[index].rotation.y = -PI*0.5 if opened else 0.0

func reset_doors() -> void:
 for i in doors.size(): set_door(i,false)
