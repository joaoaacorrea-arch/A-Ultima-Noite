extends Button

# Primary touch is handled by Godot's mouse emulation. Secondary touches need
# explicit routing so an action can be pressed while the joystick is held.
func _input(event: InputEvent) -> void:
	if not is_visible_in_tree() or disabled: return
	if event is InputEventScreenTouch and event.index > 0 and event.pressed:
		if get_global_rect().has_point(event.position):
			get_viewport().set_input_as_handled()
			pressed.emit()
