import os,subprocess,time
from pathlib import Path
cmd=[os.environ['GODOT_BIN'],'--headless','--path','.','--script','res://tests/network.gd','--']
with open('build/host.log','w') as hl,open('build/client.log','w') as cl:
 host=subprocess.Popen(cmd+['host'],stdout=hl,stderr=subprocess.STDOUT)
 client=None
 try:
  for _ in range(100):
   if 'HOST_READY' in Path('build/host.log').read_text(): break
   time.sleep(.1)
  client=subprocess.Popen(cmd+['client'],stdout=cl,stderr=subprocess.STDOUT)
  client.wait(timeout=30);host.wait(timeout=30)
  assert host.returncode==0 and client.returncode==0
  assert 'HOST_NETWORK_OK' in Path('build/host.log').read_text()
  assert 'CLIENT_NETWORK_OK' in Path('build/client.log').read_text()
  for name in ['host','client']:
   log=Path('build/'+name+'.log').read_text()
   print(log)
   assert 'SCRIPT ERROR' not in log and 'ERROR:' not in log
 finally:
  if host.poll() is None:host.kill()
  if client and client.poll() is None:client.kill()
