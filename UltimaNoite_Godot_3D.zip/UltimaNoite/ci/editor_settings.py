import os
from pathlib import Path
folder=Path.home()/'.config/godot'
folder.mkdir(parents=True,exist_ok=True)
(folder/'editor_settings-4.6.tres').write_text('[gd_resource type="EditorSettings" format=3]\n\n[resource]\nexport/android/java_sdk_path = "'+os.environ['JAVA_HOME']+'"\nexport/android/android_sdk_path = "'+os.environ['ANDROID_HOME']+'"\n')
