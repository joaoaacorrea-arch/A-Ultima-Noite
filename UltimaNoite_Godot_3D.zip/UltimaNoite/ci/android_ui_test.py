"""Exercise the installed Godot APK using Android's actual touch input dispatch."""
import json,struct,subprocess,time
from pathlib import Path
PACKAGE='com.ultimanoite.game3d'
OUT=Path('build/android_test');OUT.mkdir(parents=True,exist_ok=True)
report=[]
def adb(*args,binary=False):
 return subprocess.check_output(['adb',*args],text=not binary,stderr=subprocess.STDOUT)
def records():
 result=[]
 for line in adb('logcat','-d').splitlines():
  if 'QA:' in line:
   try:result.append(json.loads(line.split('QA:',1)[1]))
   except (ValueError,IndexError):pass
 return result
def wait_for(predicate,label,seconds=25):
 deadline=time.monotonic()+seconds
 while time.monotonic()<deadline:
  for record in reversed(records()):
   if predicate(record):
    report.append('PASS '+label)
    return record
  time.sleep(.35)
 raise AssertionError(label)
def screenshot(name):
 data=adb('exec-out','screencap','-p',binary=True)
 (OUT/(name+'.png')).write_bytes(data)
 return struct.unpack('>II',data[16:24])
def state():
 return wait_for(lambda r:r.get('event')=='state','read visible UI')
def tap_point(point,current):
 width,height=screenshot('latest')
 vw,vh=current['viewport']
 x=round(point[0]*width/vw);y=round(point[1]*height/vh)
 assert 0<=x<width and 0<=y<height,(point,width,height,current)
 adb('logcat','-c')
 adb('shell','input','tap',str(x),str(y))
def tap_button(text):
 current=state()
 assert text in current['buttons'],(text,current)
 tap_point(current['buttons'][text],current)
 wait_for(lambda r:r.get('event')=='button' and r.get('text')==text,'tap '+text)
def select(field,text,index):
 tap_button(text)
 popup=wait_for(lambda r:r.get('event')=='popup' and r.get('field')==field,'open '+field)
 current=state()
 tap_point(popup['points'][index],current)
 wait_for(lambda r:r.get('event')=='selected' and r.get('field')==field and r.get('index')==index,'select '+field)
def checks(suffix):
 initial=state()
 assert initial['menu'] and not initial['running']
 screenshot('menu_'+suffix)
 select('character','Bia',1)
 select('role','Sobrevivente',1)
 select('duration','Partida de 3 minutos',2)
 tap_button('Entrar')
 wait_for(lambda r:r.get('event')=='state' and 'Digite o IP' in r.get('info',''),'empty IP validation')
 tap_button('INICIAR PARTIDA · ANFITRIÃO')
 wait_for(lambda r:r.get('event')=='state' and 'Crie a sala' in r.get('info',''),'start validation')
 tap_button('EXPLORAR A VILA · SOZINHO')
 wait_for(lambda r:r.get('event')=='state' and r.get('running') and r.get('solo'),'enter exploration')
 screenshot('game_'+suffix)
 tap_button('CÂMERA 1ª / 3ª')
 wait_for(lambda r:r.get('event')=='state' and not r.get('first_person',True),'camera toggle')
 tap_button('AGACHAR')
 wait_for(lambda r:r.get('event')=='state' and r.get('crouching'),'crouch toggle')
 tap_button('Arma: Faca')
 wait_for(lambda r:r.get('event')=='state' and r.get('weapon')==1,'weapon selection')
 tap_button('ATACAR')
 tap_button('ABRIR / FECHAR PORTA')
 tap_button('VOLTAR AO MENU')
 wait_for(lambda r:r.get('event')=='state' and r.get('menu') and not r.get('running'),'return to menu')
 tap_button('Criar sala')
 wait_for(lambda r:r.get('event')=='state' and r.get('players')==1 and 'Sala criada' in r.get('info',''),'host LAN room')
 screenshot('room_'+suffix)

def launch():
 adb('shell','am','force-stop',PACKAGE)
 adb('logcat','-c')
 adb('shell','monkey','-p',PACKAGE,'-c','android.intent.category.LAUNCHER','1')
 wait_for(lambda r:r.get('event')=='state','launch APK',40)
try:
 adb('install','-r','build/Android_Input_Test.apk')
 adb('shell','settings','put','system','accelerometer_rotation','0')
 adb('shell','settings','put','system','user_rotation','1')
 launch();checks('16_9')
 adb('shell','am','force-stop',PACKAGE)
 adb('shell','wm','size','1080x2400')
 time.sleep(1)
 launch();checks('20_9')
 logs=adb('logcat','-d')
 assert 'FATAL EXCEPTION' not in logs and 'SCRIPT ERROR' not in logs
 report.append('ANDROID_UI_OK: real ADB touches, all dropdowns and buttons, 16:9 and 20:9 screens')
 print('\n'.join(report))
except Exception:
 try:screenshot('failure')
 except Exception:pass
 raise
finally:
 (OUT/'report.txt').write_text('\n'.join(report))
 try:(OUT/'logcat.txt').write_text(adb('logcat','-d'))
 except Exception:pass
 try:adb('shell','wm','size','reset')
 except Exception:pass
