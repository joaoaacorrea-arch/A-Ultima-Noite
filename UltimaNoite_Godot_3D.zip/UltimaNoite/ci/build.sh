#!/usr/bin/env bash
set -euo pipefail
export GODOT_VERSION=4.6.3
mkdir -p "$RUNNER_TEMP/godot" build
curl -fL --retry 3 "https://github.com/godotengine/godot-builds/releases/download/4.6.3-stable/Godot_v4.6.3-stable_linux.x86_64.zip" -o "$RUNNER_TEMP/godot.zip"
unzip -q "$RUNNER_TEMP/godot.zip" -d "$RUNNER_TEMP/godot"
export GODOT_BIN="$RUNNER_TEMP/godot/Godot_v4.6.3-stable_linux.x86_64"
chmod +x "$GODOT_BIN"
"$GODOT_BIN" --headless --editor --path . --quit 2>&1 | tee build/import.log
if rg 'SCRIPT ERROR|Parse Error|Failed to load script' build/import.log; then exit 1; fi
"$GODOT_BIN" --headless --path . --script res://tests/smoke.gd 2>&1 | tee build/smoke.log
rg 'SMOKE_OK' build/smoke.log
python3 ci/network_check.py
xvfb-run -a "$GODOT_BIN" --path . --rendering-method gl_compatibility --audio-driver Dummy --script res://tests/render.gd 2>&1 | tee build/render.log
rg 'RENDER_OK' build/render.log
curl -fL --retry 3 "https://github.com/godotengine/godot-builds/releases/download/4.6.3-stable/Godot_v4.6.3-stable_export_templates.tpz" -o "$RUNNER_TEMP/templates.tpz"
TEMPLATE_DEST="$HOME/.local/share/godot/export_templates/4.6.3.stable"
mkdir -p "$TEMPLATE_DEST"
unzip -j -q "$RUNNER_TEMP/templates.tpz" 'templates/android_debug.apk' 'templates/android_release.apk' 'templates/version.txt' -d "$TEMPLATE_DEST"
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" 'platform-tools' 'platforms;android-35' 'build-tools;35.0.1'
mkdir -p "$HOME/.config/godot" "$HOME/.android"
python3 ci/editor_settings.py
keytool -genkeypair -keystore "$HOME/.android/ultima-noite-debug.keystore" -storepass android -alias androiddebugkey -keypass android -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$HOME/.android/ultima-noite-debug.keystore"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android
"$GODOT_BIN" --headless --path . --export-debug Android build/A_Ultima_Noite_3D.apk 2>&1 | tee build/export.log
"$ANDROID_HOME/build-tools/35.0.1/apksigner" verify --verbose build/A_Ultima_Noite_3D.apk | tee build/signature.log
sha256sum build/A_Ultima_Noite_3D.apk > build/SHA256.txt
