extends SceneTree
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	root.size = Vector2i(1280,720)
	var game = load("res://scenes/Main.tscn").instantiate()
	root.add_child(game)
	for i in 10: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://preview_menu.png")
	game._explore()
	game.local_player.position = Vector3(-3,1,-20)
	game.local_player.rotation.y = 1.1
	for i in 10: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://preview_game.png")
	print("RENDER_OK")
	quit()
