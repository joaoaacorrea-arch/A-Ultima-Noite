extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var game = load("res://scenes/Main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game._explore()
	await physics_frame
	assert(game.running and game.solo and game.local_player != null)
	assert(game.world.doors.size() == 8)
	var actor = game.local_player
	var doorway: Vector3 = game.world.door_point(0)
	actor.position = doorway + Vector3(0,0,2.2)
	game._interact()
	assert(game.world.door_states[0])
	assert(game.world.door_point(0).distance_to(doorway) < 0.001)
	actor.position = Vector3(-11,1,-23)
	actor.rotation.y = 0
	actor.touch_direction = Vector2(0,-1)
	for frame in range(160): await physics_frame
	assert(actor.position.z < -28, "Player must enter the house through the open doorway")
	actor.touch_direction = Vector2(0,1)
	for frame in range(160): await physics_frame
	assert(actor.position.z > -24, "Player must exit the house")
	actor.touch_direction = Vector2.ZERO
	actor.position = doorway + Vector3(0,0,2.2)
	game._interact()
	assert(not game.world.door_states[0])
	actor.position = Vector3(-11,1,-23)
	actor.touch_direction = Vector2(0,-1)
	for frame in range(100): await physics_frame
	assert(actor.position.z > -26, "Closed door must stop the player")
	actor.touch_direction = Vector2.ZERO
	actor.toggle_camera()
	assert(not actor.first_person and actor.third_camera.current)
	game._leave()
	await process_frame
	assert(not game.running and game.players.is_empty())
	game._explore()
	assert(game.running and game.players.size() == 1)
	print("SMOKE_OK: scene, exploration, eight doors, entry/exit, closed-door collision, cameras, restart")
	quit()
