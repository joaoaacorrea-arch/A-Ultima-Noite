extends SceneTree
var game
var role := "host"
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if not args.is_empty(): role = args[0]
	call_deferred("run")
func wait_until(test: Callable, limit := 600) -> bool:
	for tick in range(limit):
		if test.call(): return true
		await process_frame
	return false
func run() -> void:
	game = load("res://scenes/Main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	if role == "host":
		game._host()
		print("HOST_READY")
		assert(await wait_until(func(): return game.players.size() == 2))
		game._start_match()
		assert(game.running)
		game.sync_door.rpc(0,true)
		var client_id = game.players.keys().filter(func(id): return id != 1)[0]
		assert(await wait_until(func(): return game.get_node("Player_%d" % client_id).position.x > 8))
		assert(game.get_node("Player_%d" % client_id).crouching)
		game.end_round.rpc("TEST_RESULT")
		for tick in range(60): await process_frame
		print("HOST_NETWORK_OK: roster, round, movement, crouch, doors, result")
	else:
		game.character_option.select(1)
		game.role_option.select(1)
		game.address_edit.text = "127.0.0.1"
		game._join()
		assert(await wait_until(func(): return game.running))
		assert(game.players.size() == 2)
		assert(await wait_until(func(): return game.world.door_states[0]))
		game.local_player.crouching = true
		# Move incrementally to stay within the server plausibility bound.
		for step in range(12):
			game.local_player.position.x += 0.7
			await create_timer(0.08).timeout
		assert(await wait_until(func(): return not game.running))
		assert(game.info.text.contains("TEST_RESULT"))
		print("CLIENT_NETWORK_OK: handshake, timer, door sync, movement, result")
	quit()
