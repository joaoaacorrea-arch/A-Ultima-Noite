extends SceneTree
var game
var errors: Array[String] = []
func _initialize() -> void:
	call_deferred("run")
func check(ok: bool, message: String) -> void:
	if not ok:
		errors.append(message)
		push_error(message)
func touch(point: Vector2, pressed: bool, index := 0) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = point
	event.pressed = pressed
	Input.parse_input_event(event)
	await process_frame
func tap(point: Vector2, index := 0) -> void:
	await touch(point,true,index)
	await touch(point,false,index)
func button(text_value: String) -> Button:
	for child in game.find_children("*","Button",true,false):
		if child.text == text_value: return child
	return null
func select_option(option: OptionButton, index: int) -> void:
	await tap(option.get_global_rect().get_center())
	for i in 3: await process_frame
	var popup := option.get_popup()
	check(popup.visible,"Option menu must open on touch")
	var panel := popup.get_theme_stylebox("panel")
	var height := popup.get_theme_font("font").get_height(popup.get_theme_font_size("font_size")) + popup.get_theme_constant("v_separation")
	var point := Vector2(popup.position) + Vector2(popup.size.x*0.5,panel.content_margin_top+height*(index+0.5))
	await tap(point)
	for i in 3: await process_frame
	check(option.selected == index,"Touch must select item %d; actual %d" % [index,option.selected])
func run() -> void:
	root.size = Vector2i(1280,720)
	root.gui_embed_subwindows = true
	game = load("res://scenes/Main.tscn").instantiate()
	root.add_child(game)
	for i in 5: await process_frame
	check(Input.is_emulating_mouse_from_touch(),"Touch-to-mouse conversion must be enabled")
	await tap(game.name_edit.get_global_rect().get_center())
	check(game.name_edit.has_focus(),"Name field must accept touch focus")
	await select_option(game.character_option,1)
	await select_option(game.role_option,1)
	await select_option(game.duration_option,2)
	await tap(game.address_edit.get_global_rect().get_center())
	check(game.address_edit.has_focus(),"IP field must accept touch focus")
	await tap(button("Entrar").get_global_rect().get_center())
	check(game.info.text.contains("Digite o IP"),"Join button must validate missing IP on touch")
	await tap(button("INICIAR PARTIDA · ANFITRIÃO").get_global_rect().get_center())
	check(game.info.text.contains("Crie a sala"),"Start button must respond before hosting")
	await tap(button("EXPLORAR A VILA · SOZINHO").get_global_rect().get_center())
	for i in 3: await process_frame
	check(game.running and game.solo,"Touch must start exploration")
	var actor = game.local_player
	check(actor != null,"Local player must spawn after touch")
	await tap(button("CÂMERA 1ª / 3ª").get_global_rect().get_center())
	check(not actor.first_person,"Camera button must respond to primary touch")
	await tap(game.crouch_button.get_global_rect().get_center())
	check(actor.crouching,"Crouch button must respond to touch")
	await tap(game.weapon_button.get_global_rect().get_center())
	check(game.weapon_index == 1,"Weapon button must respond to touch")
	var attacks := [0]
	game.attack_button.pressed.connect(func(): attacks[0] += 1)
	await tap(game.attack_button.get_global_rect().get_center())
	check(attacks[0] == 1,"Attack button must receive exactly one touch")
	var doorway: Vector3 = game.world.door_point(0)
	actor.position = doorway + Vector3(0,0,2.2)
	await tap(button("ABRIR / FECHAR PORTA").get_global_rect().get_center())
	check(game.world.door_states[0],"Door button must open a nearby door on touch")
	await touch(Vector2(110,560),true,0)
	check(actor.touch_move == 0,"Primary touch must hold the joystick")
	await tap(button("CÂMERA 1ª / 3ª").get_global_rect().get_center(),1)
	check(actor.first_person,"Secondary touch must activate camera while joystick is held")
	check(actor.touch_move == 0,"Action must preserve joystick touch")
	await touch(Vector2(110,560),false,0)
	await tap(button("VOLTAR AO MENU").get_global_rect().get_center())
	check(not game.running and game.menu.visible,"Return button must reopen menu")
	await tap(button("Criar sala").get_global_rect().get_center())
	check(game.peer != null and game.players.size() == 1,"Host button must create a LAN room on touch")
	game._leave()
	if not errors.is_empty():
		print("TOUCH_FAILED: ",errors)
		quit(1)
	else:
		print("TOUCH_INPUT_OK: fields, all dropdowns, create/join/start, explore, camera, crouch, doors, multitouch, menu")
		quit()
