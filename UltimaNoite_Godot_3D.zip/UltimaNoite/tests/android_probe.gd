extends Node
var game
var ticks := 0
var visible_popup := ""
func report(value: Dictionary) -> void:
	print("QA:"+JSON.stringify(value))
func _ready() -> void:
	game = get_parent()
	for control in game.find_children("*","Button",true,false):
		var target: Button = control
		target.pressed.connect(func(): report({"event":"button","text":target.text}))
	for entry in [["character",game.character_option],["role",game.role_option],["duration",game.duration_option]]:
		var label: String = entry[0]
		entry[1].item_selected.connect(func(index): report({"event":"selected","field":label,"index":index}))
func _process(_delta: float) -> void:
	ticks += 1
	if ticks % 30 != 0: return
	var buttons := {}
	for control in game.find_children("*","Button",true,false):
		if control.is_visible_in_tree():
			var center: Vector2 = control.get_global_rect().get_center()
			buttons[control.text] = [center.x,center.y]
	var size: Vector2 = game.get_viewport().get_visible_rect().size
	var snapshot := {"event":"state","buttons":buttons,"viewport":[size.x,size.y],"running":game.running,"solo":game.solo,"menu":game.menu.visible,"players":game.players.size(),"info":game.info.text,"character":game.character_option.selected,"role":game.role_option.selected,"duration":game.duration_option.selected,"weapon":game.weapon_index}
	if game.local_player:
		snapshot["first_person"] = game.local_player.first_person
		snapshot["crouching"] = game.local_player.crouching
	report(snapshot)
	for entry in [["character",game.character_option],["role",game.role_option],["duration",game.duration_option]]:
		var popup: PopupMenu = entry[1].get_popup()
		if not popup.visible: continue
		var panel := popup.get_theme_stylebox("panel")
		var height := popup.get_theme_font("font").get_height(popup.get_theme_font_size("font_size"))+popup.get_theme_constant("v_separation")
		var points := []
		for index in popup.item_count:
			var point := Vector2(popup.position)+Vector2(popup.size.x*0.5,panel.content_margin_top+height*(index+0.5))
			points.append([point.x,point.y])
		report({"event":"popup","field":entry[0],"points":points})
