# A Última Noite — protótipo jogável 3D

Godot 4.6.3, GDScript, renderizador Compatibility. Projeto baseado no ZIP 3D fornecido.

## Recursos
- Vila com oito casas, floresta, lanternas e atmosfera noturna.
- Personagens Bia e João representados por modelos geométricos estilizados.
- Exploração individual offline, sem inimigo automático.
- Partida de dois jogadores na mesma rede Wi-Fi: um assassino e um sobrevivente.
- Escolha de duração 3/5/7 minutos, vitória por tempo ou ataque próximo sem parede no caminho.
- Portas físicas que abrem e fecham, sincronizadas entre os jogadores.
- Câmera em primeira/terceira pessoa, joystick de toque, agachar e voltar ao menu.
- Teclado: WASD/setas; olhar: botão direito do mouse; E: porta; C: câmera.

## No Android
Instale A_Ultima_Noite_3D.apk. O pacote com.ultimanoite.game3d é separado da demo 2D anterior.
Escolha EXPLORAR A VILA para testar sozinho. Para jogar em dupla, ambos devem instalar esta
mesma versão e usar a mesma rede. Um cria a sala; o outro informa o IP mostrado, escolhe
personagem e papel opostos e entra. O anfitrião inicia. Redes com isolamento de clientes
podem impedir a conexão UDP na porta 24567.

## Limites
Não inclui login Google, salas por código, servidor público, bot, animações de combate
ou gráficos fotorrealistas. A rede é um protótipo LAN, com validação básica de movimento;
não é uma arquitetura de produção resistente a trapaças. O visual não é idêntico à arte
conceitual. A versão de teste usa uma chave de depuração descartável; novas compilações
podem exigir remover uma instalação anterior com o mesmo pacote.

## Desenvolvimento
Importe project.godot no Godot 4.6.3. Rode a cena principal. O arquivo export_presets.cfg
inclui a exportação Android assinada para testes (ARM32/ARM64).
ci/build.sh baixa ferramentas oficiais, executa os testes de cena, colisão e rede, renderiza
prévias reais e exporta o APK. Requer Linux com SDK Android, Java 17 e xvfb-run.
Os testes de rede executam dois processos no mesmo computador; não substituem teste físico
em dois celulares. Não houve teste em aparelho Android real durante a criação.

Godot Engine é distribuído sob a licença MIT: https://godotengine.org/license/

## Correção de toque v0.4
- Conversão de toque em clique habilitada para os controles do menu.
- Ações com segundo dedo enquanto o joystick é mantido pressionado.
- Teste de regressão reproduz a falha anterior e verifica campos, seletores e botões.
- APK adicional x86_64 exclusivo de QA para testes reais por ADB no emulador Android.
- Google e salas pela internet dependem da configuração de um projeto de autenticação e backend; não estão ativados neste pacote.
